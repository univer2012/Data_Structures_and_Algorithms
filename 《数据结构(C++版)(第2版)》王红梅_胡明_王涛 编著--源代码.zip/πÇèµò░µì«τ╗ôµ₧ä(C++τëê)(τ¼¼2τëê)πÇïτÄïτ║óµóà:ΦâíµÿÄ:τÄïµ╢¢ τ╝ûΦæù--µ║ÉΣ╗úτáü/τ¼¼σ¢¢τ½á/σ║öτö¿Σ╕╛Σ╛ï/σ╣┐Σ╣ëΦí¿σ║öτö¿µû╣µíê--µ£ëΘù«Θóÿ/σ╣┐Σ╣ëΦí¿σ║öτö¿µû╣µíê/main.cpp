//
//  main.cpp
//  广义表应用方案
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#include <iostream>      //引用输入输出流库函数的头文件
#include "GeneralizedLists.cpp"  ////引用广义表的成员函数文件
//#include <string> //引用string库函数的头文件
//using namespace std; //指出后续的所有的程序语句都在名字空间std内

int main(int argc, const char * argv[]) {
    // insert code here...
    
    string info;//存储人员信息
    int stutrueflag =1; //开关标志
    int which;        //功能选择变量
    int choose=1;    //控制
    string insertstuinfo; //要插入学生的信息
    string stuname;//人员姓名
    cout << "首先请初始化广义表，格式如：(高老师-教授-0,(李刚-二班-1,(李明-二班-2)))" << "\n";
    GLists <Personnel> *stulists;  //声明stulists广义表
    while( stutrueflag ) //保证用户建立正确的广义表，如果错误让用户不停的输入，直到输入正确
    {
        try
        {
            cin >> info;
            stulists = new GLists<Personnel>(info);  //生成info表示的广义表
            stutrueflag=0; // 开关标志,结束while循环
        }
        catch(char * )
        {
            cout << "输入格式不正确" << "\n";     //如失败提示失败信息
        }
    }
    while ( choose==1 )
    {
        
        cout << "需要插入学生请按1" << "\n";
        cout << "需要删除学生请按2" << "\n";
        cout << "需要查询信息请按3" << "\n";
        cout << "需要输出信息请按4" << "\n";
        cout << "统计导师带的学生数请按5" << "\n";
        cout << "输出广义表请按6" << "\n";
        cout << "需要退出请按7" << "\n";
        cin >> which;
        switch( which )
        {
            case 1:
                cout << "请输入需要插入学生信息，格式如:李刚-二班-1" << "\n";
                cin>>insertstuinfo;
                cout << "请输入学生姓名:" << "\n";
                cin>>stuname;
                try
            {
                stulists->Setinfo();//初始化广义表的信息
                if( stulists->InsertStudent(stulists->Getls(),stuname,insertstuinfo) )//向广义表中插入数据
                    cout<<"插入成功";
                else
                    cout<<"插入失败";
                cout << "\n";//换行
            }
                catch(char * )
            {
                cout << "插入失败n";
            }
                break;
                
            case 2:
                
                cout << "请输入要删除学生姓名：" << "\n";
                cin>>stuname;//输入要删除的学生的姓名
                try
            {
                stulists->Setinfo(); //初始化广义表的信息
                if( stulists->DelStudent(stulists->Getls(),stuname) )//删除指定的学生
                    cout<<"删除成功";
                else
                    cout<<"删除失败";
                cout << "\n";  //换行
            }
                catch(char * )
            {
                cout << "删除失败";
            }
                break;
            case 3:
                
                cout << "请输入要查询者的姓名："<< "\n";
                cin>>stuname; //输入要查询的姓名
                try
            {
                stulists->Setinfo(); //初始化广义表的信息
                stulists->QueryInfo(stulists->Getls(),stuname);//查询姓名为stuname的信息
                stulists->Outinfo(); //输出查询结果
                cout << "\n";
            }
                catch(char * )
            {
                cout << "查询失败";
            }
                break;
                
            case 4:
                
                cout << "请输入老师的姓名："<< "\n";
                cin>>stuname;
                try
            {
                stulists->Setinfo();//初始化广义表的信息
                stulists->StudentInfo(stulists->Getls(),stuname); //显示姓名为stuname的老师的学生信息
                stulists->Outinfo();//输出结果
                cout << "\n";
            }
                catch(char * )
            {
                cout << "搜索失败";
            }
                break;
            case 5:
                
                cout << "请输入老师的姓名："<< "\n";
                cin>>stuname;
                try
            {
                stulists->Setinfo();//初始化广义表的信息
                stulists->StatisticInfo(stulists->Getls(),stuname);//统计姓名为stuname的老师的学生人数情况
                stulists->OutStatisticinfo();//输出结果
                cout << "\n";
            }
                catch(char * )
            {
                cout << "统计失败";
            }
                break;
            case 6:
                try
            {
                stulists->Setinfo(); //初始化广义表的信息
                stulists->Prnt(); //显示广义表
                cout << "\n";
            }
                catch(char * )
            {
                cout << "显示失败";
            }
                break;
            case 7:
                choose=0;//设置退出标识
                break;
                
            default:break;
        }
    }
    
    return 0;
}
