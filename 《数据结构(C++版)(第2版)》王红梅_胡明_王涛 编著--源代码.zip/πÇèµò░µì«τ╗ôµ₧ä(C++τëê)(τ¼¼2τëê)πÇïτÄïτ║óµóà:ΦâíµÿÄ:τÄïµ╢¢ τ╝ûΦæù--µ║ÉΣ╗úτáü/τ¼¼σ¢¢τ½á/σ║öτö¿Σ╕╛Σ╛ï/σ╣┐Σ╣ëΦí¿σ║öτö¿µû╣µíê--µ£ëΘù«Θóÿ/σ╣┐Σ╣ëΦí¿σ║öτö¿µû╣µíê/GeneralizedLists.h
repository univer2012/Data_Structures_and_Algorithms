//
//  GeneralizedLists.h
//  广义表应用方案
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#ifndef ___________GeneralizedLists__
#define ___________GeneralizedLists__

#include <stdio.h>
#include <string>
using namespace std;

class Personnel
{
public:
    Personnel(string st);//有参构造函数，把st表示的信息转化为人员的相应信息
    Personnel(){personnelinfo="";personnelname=""; tag=0;} //无参构造函数，初始化人员信息
    string GetPersonnelinfo();//返回学生班级和教师职称信息
    int GetTag();//返回人员类型
    string GetPersonnelname(); //返回人员姓名
    
private:
    int tag;    //标识人员的类型
    string personnelinfo; //学生班级和教师职称
    string personnelname; //人员姓名
};

template <class T>
struct  GLNode
{
    int  tag;                //标志域，用于区分元素结点和表结点
    T data;                  //data是元素结点的数据域
    struct atom
    {
        GLNode *hp, *tp;       //hp和tp分别指向表头和表尾
    } ptr;
    
};

template <class T>
class GLists
{
public:
    GLists(){ls = NULL;outflag =false;Numbergraduate =0;NumberStudent=0;}//无参构造函数，初始化为空的广义表
    GLists(string st);//有参构造函数，按广义表的书面格式建立广义表的存储结构
    GLists(GLists ls1, GLists ls2);   //有参构造函数，用表头ls1和表尾ls2构造广义表
    ~GLists( ){delete [] ls;}   //析构函数，释放广义表中各结点的存储空间
    int Depth( GLNode<T> *ls );   //求广义表的深度
    GLists<T> *Head( );  //求广义表的表头
    GLists<T> *Tail( );   //求广义表的表尾
    void Prnt(); //将广义表显示出来
    void  QueryInfo(GLNode<T>* ls,string manname);//查询ls所指的广义表中的姓名为manname的信息
    void  StatisticInfo(GLNode<T>* ls,string mannameg);//统计ls所指的广义表中的姓名为manname的老师所带的学生人数
    void  StudentInfo(GLNode<T>* ls,string mannameg);//显示ls所指的广义表中的姓名为manname的老师所带的学生
    bool  DelStudent(GLNode<T>* ls,string mannameg); //删除ls所指的广义表中的姓名为manname的学生
    bool  InsertStudent(GLNode<T>* ls,string mannameg,string stuinfo); //把学生信息为stuinfo的学生插入到ls所指的广义表中的姓名为manname的后边
    void  Setinfo();//初始化广义表的信息
    void  Outinfo();//输出广义表的信息
    GLNode<T>* Getls();//输出广义表的ls成员
    void OutStatisticinfo() ;//显示统计姓名为manname的老师所带的学生人数的信息
    
private:
    GLNode<T>* ls;  //ls是指向广义表的头指针
    string stprt;//显示一些操作信息
    void Server(string &st,string &hst); // 从st中取出第一成员存入到hst，其余的成员留在st中
    GLNode<T>* Crtlists(string st);//把广义表的书面格式st转化为广义表的头尾存储结构
    void Ena(string str);//把str表示信息存储到stprt中，已备以后显示
    void Prt(GLNode<T>* ls);//将ls所指的广义表显示出来
    int NumberStudent; //记录本科生的人数
    int Numbergraduate;//记录研究生的人数
    bool outflag ;//开关标识
};

#endif /* defined(___________GeneralizedLists__) */
