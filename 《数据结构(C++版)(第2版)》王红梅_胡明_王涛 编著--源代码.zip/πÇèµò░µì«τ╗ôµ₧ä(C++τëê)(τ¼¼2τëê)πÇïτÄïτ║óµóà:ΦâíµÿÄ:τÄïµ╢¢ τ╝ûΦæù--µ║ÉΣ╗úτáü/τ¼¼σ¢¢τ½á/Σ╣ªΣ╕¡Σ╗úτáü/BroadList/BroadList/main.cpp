//
//  main.cpp
//  BroadList
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#include <iostream>      //引用输入输出流库函数的头文件
#include "BroadList.cpp"  //引用广义表的成员函数文件
#include <string> //引用string库函数的头文件
using namespace std; //指出后续的所有的程序语句都在名字空间std内

int main(int argc, const char * argv[]) {
    // insert code here...
    
    try {
        GLists<char> *stulists,*stulistsHead,*stulistsTail,*stulistsAdd;
        stulists = new GLists<char>("(a,b,(a,b))");  //生成info表示的广义表
        cout<<"初始构建的广义表为："<<"\n";
        stulists->Prnt();
        cout<<"\n"<<"广义表的长度为：";
        cout<<stulists->Length();
        cout<<"\n"<<"广义表的深度为：";
        cout<<stulists->DepthGList();
        stulistsHead = stulists->Head();
        cout<<"\n"<<"广义表的头指针为：";
        stulistsHead->Prnt();
        stulistsTail = stulists->Tail();
        cout<<"\n"<<"广义表的尾指针为：";
        stulistsTail->Prnt();
        stulistsAdd = new GLists<char>(*stulistsHead,*stulistsTail);
        cout<<"\n"<<"广义表的尾指针和头指针生成的新广义表为：";
        stulistsAdd->Prnt();
    } catch(char * e) {
        cout<<"广义表处理失败,原因如下：";
        cout<<e;
    }
    
    return 0;
}
