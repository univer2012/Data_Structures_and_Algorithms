//
//  main.cpp
//  SparseMatrix
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#include <iostream>      //引用输入输出流库函数的头文件
#include "SparseMatrix.cpp"  ////引用广义表的成员函数文件
#include <string> //引用string库函数的头文件
using namespace std; //指出后续的所有的程序语句都在名字空间std内

int main(int argc, const char * argv[]) {
    // insert code here...
    
    try {
        //建立一个element<int>类型的数组(A)
        element<int> elementtemp,elementtemp3,elementtemp2;
        elementtemp.col=0;elementtemp.row = 0 ;elementtemp.item = 15;
        elementtemp2.col=1;elementtemp2.row = 2 ;elementtemp2.item = 16;
        elementtemp3.col=1;elementtemp3.row = 0 ;elementtemp3.item = 17;
        element<int> A[3];A[0] = elementtemp;A[1] = elementtemp2;A[2] = elementtemp3;
        
        SparseMatrix<int> sparsematrixB;//构造三元组顺序表来存储转置后的三元组顺序表
        SparseMatrix<int> sparsematrixA(3,3,3,A);//构造三元组顺序表
        cout<<"源三元组顺序表如下:"<<"\n";
        sparsematrixA.Prt();//显示三元组顺序表
        sparsematrixA.Trans1(sparsematrixB);
        cout<<"使用直接取、顺序存转置算法转置后的三元组顺序表如下:"<<"\n";
        sparsematrixB.Prt();//显示三元组顺序表
        sparsematrixA.Trans2(sparsematrixA,sparsematrixB);
        cout<<"使用顺序取、直接存转置算法转置后的三元组顺序表如下:"<<"\n";
        sparsematrixB.Prt();//显示三元组顺序表
    } catch(char* e) {
        cout<<e;
    }
    
    return 0;
}
