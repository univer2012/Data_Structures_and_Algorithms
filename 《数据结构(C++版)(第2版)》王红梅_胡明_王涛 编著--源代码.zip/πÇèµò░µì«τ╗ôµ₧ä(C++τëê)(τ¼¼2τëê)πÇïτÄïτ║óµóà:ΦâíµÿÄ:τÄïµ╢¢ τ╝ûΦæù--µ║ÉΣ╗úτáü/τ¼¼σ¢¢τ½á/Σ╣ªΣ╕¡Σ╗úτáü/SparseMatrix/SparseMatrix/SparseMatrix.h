//
//  SparseMatrix.h
//  SparseMatrix
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#ifndef __SparseMatrix__SparseMatrix__
#define __SparseMatrix__SparseMatrix__

#include <stdio.h>

template <class T>
struct element
{
    int row, col; //行数、列数
    T item; //元素值
};
const int MaxTerm=100;
template <class T>
class SparseMatrix
{
public:
    SparseMatrix(){};
    SparseMatrix(int intmu,int intnu,int inttu,element<T> datatemp[]);//有参构造函数，初始化稀疏矩阵
    ~SparseMatrix(){}; //析构函数，释放存储空间
    element<T> GetMatrix(int intnumber);//输出下标对应的数组元素
    void Prt();//显示三元组顺序表
    void Trans1(SparseMatrix<T> &B);//直接取、顺序存的矩阵转置算法
    void Trans2(SparseMatrix<T> A, SparseMatrix<T> &B);//顺序取、直接存的矩阵转置算法
private:
    element<T> data[MaxTerm]; //矩阵非零元素
    int mu, nu, tu;   //行数、列数、非零元个数
};

#endif /* defined(__SparseMatrix__SparseMatrix__) */
