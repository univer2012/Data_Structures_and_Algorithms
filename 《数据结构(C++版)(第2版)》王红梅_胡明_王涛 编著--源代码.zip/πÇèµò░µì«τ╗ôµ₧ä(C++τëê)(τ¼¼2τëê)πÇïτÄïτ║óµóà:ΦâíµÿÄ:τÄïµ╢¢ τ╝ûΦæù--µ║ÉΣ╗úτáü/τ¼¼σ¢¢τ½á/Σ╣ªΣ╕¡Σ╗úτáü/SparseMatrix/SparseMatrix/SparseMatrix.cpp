//
//  SparseMatrix.cpp
//  SparseMatrix
//
//  Created by huangaengoln on 15/10/11.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

#include "SparseMatrix.h" //引用三元组顺序表的头文件
//#include <string> //引用string库函数的头文件
using namespace std;//指出后续的所有的程序语句都在名字空间std内
#include <iostream>

/*
 前置条件：三元组顺序表不存在
 输入：三元组顺序表的行数(intmu)、列数(intnu)、非零元个数(inttu)、初始三元组(datatemp[])
 功能：三元组顺序表的初始化
 输出：无
 后置条件：建立一个三元组顺序表
 */
template <class T>
SparseMatrix<T>::SparseMatrix(int intmu,int intnu,int inttu,element<T> datatemp[])
{
    if (inttu >MaxTerm ) throw "构造函数的初始化参数不正确";
    mu = intmu;nu = intnu;tu = inttu;
    for(int i=0;i<inttu;i++)
    {
        data[i] = datatemp[i];
    }
    
}
/*
 前置条件：三元组顺序表已存在
 输入：下标(intnumber)
 功能：读取这组下标对应的数组元素
 输出：对应元素
 后置条件：三元组顺序表不变
 */
template <class T>
element<T> SparseMatrix<T>::GetMatrix(int intnumber)
{
    if(intnumber>=tu || intnumber < 0) throw "输入位置不正确";
    return data[intnumber];
    
}

/*
 前置条件：无
 输入：无
 功能：显示三元组顺序表
 输出：无
 后置条件：建立一个三元组顺序表
 */
template <class T>
void SparseMatrix<T>::Prt()
{
    
    for(int i=0;i<tu;i++)
    {
        cout<<data[i].col<<" "<<data[i].row<<" "<<data[i].item<<"\n";
    }
    
}



/*
 前置条件：无
 输入：待转置的源三元组顺序表(A)和目标三元组顺序表(B)的引用
 功能：对三元组顺序表进行转置
 输出：无
 后置条件：三元组顺序表A的转置结果放在了B中
 */
template <class T>
void SparseMatrix<T>::Trans1(SparseMatrix<T> &B)
{
    int pb,pa;
    B.mu=this->nu; B.nu=this->mu; B.tu=this->tu;//设置行数、列数、非零元素个数
    
    if (B.tu>0) //有非零元素则转换
    {
        
        pb = 0;
        for (int col=0; col<this->nu; col++)  //依次考察每一列
            for (pa=0; pa<this->tu; pa++)  //在A中扫描整个三元组表
                if (this->data[pa].col==col ) //处理col列元素
                {
                    B.data[pb].row= this->data[pa].col ;
                    B.data[pb].col= this->data[pa].row ;
                    B.data[pb].item= this->data[pa].item;
                    pb++;
                }
        
    }
}

/*
 前置条件：无
 输入：待转置的源三元组顺序表(A)和目标三元组顺序表(B)的引用
 功能：对三元组顺序表进行转置
 输出：无
 后置条件：三元组顺序表A的转置结果放在了B中
 */
template <class T>
void SparseMatrix<T>::Trans2(SparseMatrix<T> A, SparseMatrix<T> &B)
{
    int i,j,k,num[MaxTerm],cpot[MaxTerm];
    B.mu=A.nu;  B.nu=A.mu;  B.tu=A.tu;//设置行数、列数、元素个数
    if (B.tu>0)  //有非零元素则转换
    {
        for (i=0; i<A.nu; i++)    //A中每一列非零元素的个数初始化为0
            num[i]=0;
        for (i=0; i<A.tu; i++)//求矩阵A中每一列非零元素的个数
        {
            j= A.data[i].col;     //取三元组的列号
            num[j]++;
        }
        cpot[0]=0;     //A中第0列第一个非零元素在B中的位置为0
        for (i=1; i<A.nu; i++)  //求A中每一列第一个非零元素在B中的下标
            cpot[i]= cpot[i-1]+num[i-1];
        for (i=0; i<A.tu; i++)//扫描三元组表A
        {
            j=A.data[i].col;      //当前三元组的列号
            k=cpot[j]; //当前三元组在B中的下标
            B.data[k].row= A.data[i].col ;
            B.data[k].col= A.data[i].row ;
            B.data[k].item= A.data[i].item;
            cpot[j]++;             //预置同一列的下一个三元组的下标
        }  
    }
}
