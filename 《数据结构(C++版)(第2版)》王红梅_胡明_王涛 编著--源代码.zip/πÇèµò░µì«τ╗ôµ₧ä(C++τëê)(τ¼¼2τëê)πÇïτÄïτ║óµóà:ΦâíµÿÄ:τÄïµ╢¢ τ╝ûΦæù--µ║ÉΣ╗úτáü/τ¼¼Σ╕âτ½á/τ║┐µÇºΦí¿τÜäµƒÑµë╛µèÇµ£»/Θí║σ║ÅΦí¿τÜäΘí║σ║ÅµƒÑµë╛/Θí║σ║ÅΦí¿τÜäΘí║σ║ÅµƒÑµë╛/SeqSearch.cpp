//
//  SeqSearch.cpp
//  顺序表的顺序查找
//
//  Created by huangaengoln on 15/10/6.
//  Copyright (c) 2015年 huangaengoln. All rights reserved.
//

//int SeqSearch1(int r[], int n, int k){
//    r[0]=k ;          //设置哨兵
//    int i=n;
//    while (r[i]!=k)   //若r[i]与k相等，则返回当前i的值;否则继续比较前一个记录;
//        i--;
//    return i;
//}
